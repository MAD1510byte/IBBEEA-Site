import { useState, useMemo } from "react";

const BG = "#060d18", CARD = "#0b1625", BORDER = "#1a2d44", GOLD = "#d4a853";

const ORGAN_INFO = {
  F:  { name: "Fígado",           abbr: "F",  element: "Madeira", yin: true  },
  VB: { name: "Vesícula Biliar",  abbr: "VB", element: "Madeira", yin: false },
  C:  { name: "Coração",          abbr: "C",  element: "Fogo",    yin: true  },
  ID: { name: "Intest. Delgado",  abbr: "ID", element: "Fogo",    yin: false },
  CS: { name: "Pericárdio",       abbr: "CS", element: "Fogo",    yin: true  },
  TA: { name: "Triplo Aquecedor", abbr: "TA", element: "Fogo",    yin: false },
  BP: { name: "Baço-Pâncreas",    abbr: "BP", element: "Terra",   yin: true  },
  E:  { name: "Estômago",         abbr: "E",  element: "Terra",   yin: false },
  P:  { name: "Pulmão",           abbr: "P",  element: "Metal",   yin: true  },
  IG: { name: "Intest. Grosso",   abbr: "IG", element: "Metal",   yin: false },
  R:  { name: "Rim",              abbr: "R",  element: "Água",    yin: true  },
  B:  { name: "Bexiga",           abbr: "Be", element: "Água",    yin: false },
};

const ELEMENTS = {
  Madeira: { color:"#4ade80", dark:"#041a0a", symbol:"木", organs:["F","VB"]         },
  Fogo:    { color:"#f87171", dark:"#1f0707", symbol:"火", organs:["C","ID","CS","TA"]},
  Terra:   { color:"#fbbf24", dark:"#1a1303", symbol:"土", organs:["BP","E"]          },
  Metal:   { color:"#94a3b8", dark:"#0c1420", symbol:"金", organs:["P","IG"]          },
  Água:    { color:"#60a5fa", dark:"#040e1d", symbol:"水", organs:["R","B"]           },
};

const PENTA = [
  { element:"Fogo",    angle:-90      },
  { element:"Terra",   angle:-90+72   },
  { element:"Metal",   angle:-90+144  },
  { element:"Água",    angle:-90+216  },
  { element:"Madeira", angle:-90+288  },
];

const QUESTIONS = [
  { id:1, title:"Sabores", type:"single", subtitle:"Qual sabor você prefere ou sente mais vontade? (só uma opção)",
    options:[
      { label:"Azedo / Ácido", hint:"Madeira", tags:[{type:"element",element:"Madeira"}] },
      { label:"Amargo",        hint:"Fogo",    tags:[{type:"element",element:"Fogo"   }] },
      { label:"Doce",          hint:"Terra",   tags:[{type:"element",element:"Terra"  }] },
      { label:"Picante",       hint:"Metal",   tags:[{type:"element",element:"Metal"  }] },
      { label:"Salgado",       hint:"Água",    tags:[{type:"element",element:"Água"   }] },
    ]
  },
  { id:2, title:"Proteínas", type:"single", subtitle:"Qual carne você mais prefere? (só uma opção)",
    options:[
      { label:"Frango",   hint:"Madeira", tags:[{type:"element",element:"Madeira"}] },
      { label:"Carneiro", hint:"Fogo",    tags:[{type:"element",element:"Fogo"   }] },
      { label:"Vaca",     hint:"Terra",   tags:[{type:"element",element:"Terra"  }] },
      { label:"Peixe",    hint:"Metal",   tags:[{type:"element",element:"Metal"  }] },
      { label:"Porco",    hint:"Água",    tags:[{type:"element",element:"Água"   }] },
    ]
  },
  { id:3, title:"Clima", type:"single", subtitle:"Qual clima mais te incomoda? (só uma opção)",
    options:[
      { label:"Vento",   hint:"Madeira", tags:[{type:"element",element:"Madeira"}] },
      { label:"Calor",   hint:"Fogo",    tags:[{type:"element",element:"Fogo"   }] },
      { label:"Umidade", hint:"Terra",   tags:[{type:"element",element:"Terra"  }] },
      { label:"Seco",    hint:"Metal",   tags:[{type:"element",element:"Metal"  }] },
      { label:"Frio",    hint:"Água",    tags:[{type:"element",element:"Água"   }] },
    ]
  },
  { id:4, title:"Alimentação", type:"multiple", subtitle:"Como é sua alimentação? (selecione todos que se aplicam)",
    options:[
      { label:"Normal",                       tags:[] },
      { label:"Come muito",                   hint:"Exc. BP",   tags:[{type:"Exc",organ:"BP"}] },
      { label:"Come mais alimentos naturais", tags:[] },
      { label:"Come o que tiver",             hint:"Exc. E",    tags:[{type:"Exc",organ:"E" }] },
      { label:"Prefere alimentos frios",      hint:"Exc. C",    tags:[{type:"Exc",organ:"C" }] },
      { label:"Come pouco",                   hint:"Def. BP",   tags:[{type:"Def",organ:"BP"}] },
      { label:"Sem apetite",                  hint:"Def. BP/E", tags:[{type:"Def",organ:"BP"},{type:"Def",organ:"E"}] },
      { label:"Prefere alimentos quentes",    hint:"Def. R",    tags:[{type:"Def",organ:"R" }] },
    ]
  },
  { id:5, title:"Boca e Gosto", type:"multiple", subtitle:"Selecione todos que se aplicam",
    options:[
      { label:"Normal",               tags:[] },
      { label:"Excesso de salivação", hint:"Exc. BP",   tags:[{type:"Exc",organ:"BP"}] },
      { label:"Boca amarga",          hint:"Exc. F/VB", tags:[{type:"Exc",organ:"F"},{type:"Exc",organ:"VB"}] },
      { label:"Gosto doce",           hint:"Exc. BP",   tags:[{type:"Exc",organ:"BP"}] },
      { label:"Gosto azedo",          hint:"Exc. F",    tags:[{type:"Exc",organ:"F" }] },
      { label:"Boca seca",            hint:"Def. P/R",  tags:[{type:"Def",organ:"P"},{type:"Def",organ:"R"}] },
      { label:"Sangramentos",         hint:"Exc. E",    tags:[{type:"Exc",organ:"E" }] },
      { label:"Aftas",                hint:"Exc. E/C",  tags:[{type:"Exc",organ:"E"},{type:"Exc",organ:"C"}] },
    ]
  },
  { id:6, title:"Dores", type:"multiple", subtitle:"Padrão de estagnação — selecione todos que se aplicam",
    options:[
      { label:"Não tem",           tags:[] },
      { label:"Cervical",          hint:"VB / Be",    tags:[{type:"Estag",organ:"VB"},{type:"Estag",organ:"B"}] },
      { label:"Torácica",          hint:"P / Be",     tags:[{type:"Estag",organ:"P" },{type:"Estag",organ:"B"}] },
      { label:"Lombar",            hint:"Be / Def.R", tags:[{type:"Estag",organ:"B" },{type:"Def",  organ:"R"}] },
      { label:"Ciático",           hint:"Be",         tags:[{type:"Estag",organ:"B" }] },
      { label:"Joelho articular",  hint:"VB",         tags:[{type:"Estag",organ:"VB"}] },
      { label:"Joelho ósseo",      hint:"Def. R",     tags:[{type:"Def",  organ:"R" }] },
      { label:"Ombro ósseo",       hint:"Def. R",     tags:[{type:"Def",  organ:"R" }] },
      { label:"Ombro articular",   hint:"VB",         tags:[{type:"Estag",organ:"VB"}] },
      { label:"Câimbra",           hint:"Def. F",     tags:[{type:"Def",  organ:"F" }] },
      { label:"Bruxismo",          hint:"Estag. F",   tags:[{type:"Estag",organ:"F" },{type:"Exc",organ:"E"}] },
      { label:"ATM",               hint:"VB",         tags:[{type:"Estag",organ:"VB"}] },
      { label:"Bico de Papagaio",  hint:"Def. BP/R",  tags:[{type:"Def",  organ:"BP"},{type:"Def",organ:"R"}] },
      { label:"Fraqueza muscular", hint:"Def. BP",    tags:[{type:"Def",  organ:"BP"}] },
      { label:"Rigidez articular", hint:"Estag. VB",  tags:[{type:"Estag",organ:"VB"},{type:"Def",organ:"F"}] },
    ]
  },
  { id:7, title:"Dores de Cabeça", type:"multiple", subtitle:"Padrão excesso — selecione todos que se aplicam",
    options:[
      { label:"Não tem",   tags:[] },
      { label:"Frontal",   hint:"Exc. E",  tags:[{type:"Exc",organ:"E" }] },
      { label:"Temporal",  hint:"Exc. VB", tags:[{type:"Exc",organ:"VB"}] },
      { label:"Orbital",   hint:"Exc. F",  tags:[{type:"Exc",organ:"F" }] },
      { label:"Occipital", hint:"Exc. Be", tags:[{type:"Exc",organ:"B" }] },
    ]
  },
  { id:8, title:"Sono", type:"multiple", subtitle:"Selecione todos que se aplicam",
    options:[
      { label:"Dorme bem",                 tags:[] },
      { label:"Insônia",                   hint:"Exc. C",  tags:[{type:"Exc",organ:"C" }] },
      { label:"Muito sono após refeições", hint:"Def. BP", tags:[{type:"Def",organ:"BP"}] },
      { label:"Pouco sono",                hint:"Exc. C",  tags:[{type:"Exc",organ:"C" }] },
      { label:"Pesadelos",                 hint:"Exc. F",  tags:[{type:"Exc",organ:"F" }] },
      { label:"Muito sono",                hint:"Def. BP", tags:[{type:"Def",organ:"BP"}] },
    ]
  },
  { id:9, title:"Sede", type:"multiple", subtitle:"Normal: 1,5 a 2,5 L/dia — selecione todos que se aplicam",
    options:[
      { label:"Normal (1,5–2,5 L/dia)",  tags:[] },
      { label:"Prefere água natural",     tags:[] },
      { label:"Prefere água gelada",      hint:"Calor Int.",  tags:[{type:"Exc",organ:"C" }] },
      { label:"Pouca água (< 1 L/dia)",  hint:"Def. R",      tags:[{type:"Def",organ:"R" }] },
      { label:"Muita água (> 3 L/dia)",  hint:"Exc. C/E",    tags:[{type:"Exc",organ:"C"},{type:"Exc",organ:"E"}] },
      { label:"Sem sede",                hint:"Def. R",      tags:[{type:"Def",organ:"R" }] },
      { label:"Pouca sede",              hint:"Def. BP",     tags:[{type:"Def",organ:"BP"}] },
      { label:"Muita sede",              hint:"Exc. E",      tags:[{type:"Exc",organ:"E" }] },
    ]
  },
  { id:10, title:"Fala", type:"multiple", subtitle:"Padrão Coração — selecione todos que se aplicam",
    options:[
      { label:"Normal",             tags:[] },
      { label:"Fala muito alto",    hint:"Exc. C",   tags:[{type:"Exc",organ:"C" }] },
      { label:"Fala muito baixo",   hint:"Def. C",   tags:[{type:"Def",organ:"C" }] },
      { label:"Fala muito",         hint:"Exc. C",   tags:[{type:"Exc",organ:"C" }] },
      { label:"Pouca fala",         hint:"Def. C",   tags:[{type:"Def",organ:"C" }] },
      { label:"Sem fala",           hint:"Def. C/R", tags:[{type:"Def",organ:"C"},{type:"Def",organ:"R"}] },
      { label:"Fala incoerente",    hint:"Def. C",   tags:[{type:"Def",organ:"C" }] },
      { label:"Gagueira",           hint:"Exc. F",   tags:[{type:"Exc",organ:"F" }] },
      { label:"Afonia súbita",      hint:"Def. P",   tags:[{type:"Def",organ:"P" }] },
      { label:"Rouquidão gradual",  hint:"Def. P",   tags:[{type:"Def",organ:"P" }] },
    ]
  },
  { id:11, title:"Respiração", type:"multiple", subtitle:"Selecione todos que se aplicam",
    options:[
      { label:"Normal",              tags:[] },
      { label:"Respiração fraca",    hint:"Def. P",   tags:[{type:"Def",  organ:"P"}] },
      { label:"Respiração forçada",  hint:"Def. P",   tags:[{type:"Def",  organ:"P"}] },
      { label:"Falta de ar",         hint:"Def. P/R", tags:[{type:"Def",  organ:"P"},{type:"Def",organ:"R"}] },
      { label:"Dispneia",            hint:"Estag. P", tags:[{type:"Estag",organ:"P"}] },
      { label:"Tosse seca",          hint:"Def. P",   tags:[{type:"Def",  organ:"P"}] },
      { label:"Tosse rouca",         hint:"Def. P",   tags:[{type:"Def",  organ:"P"}] },
      { label:"Tosse grossa",        hint:"Exc. F/P", tags:[{type:"Exc",  organ:"F"},{type:"Exc",organ:"P"}] },
      { label:"Suspiro frequente",   hint:"Estag. F", tags:[{type:"Estag",organ:"F"}] },
      { label:"Bronquite",           hint:"Exc. P",   tags:[{type:"Exc",  organ:"P"}] },
      { label:"Asma",                hint:"Def. P/R", tags:[{type:"Def",  organ:"P"},{type:"Def",organ:"R"}] },
      { label:"Rinite / Sinusite",   hint:"Exc. IG",  tags:[{type:"Exc",  organ:"IG"}] },
    ]
  },
  { id:12, title:"Nariz e Olfato", type:"multiple", subtitle:"Selecione todos que se aplicam",
    options:[
      { label:"Normal",           tags:[] },
      { label:"Olfato fraco",     hint:"Def. P",    tags:[{type:"Def",  organ:"P" }] },
      { label:"Perda de olfato",  hint:"Def. IG",   tags:[{type:"Def",  organ:"IG"}] },
      { label:"Coriza com muco",  hint:"Exc. P/IG", tags:[{type:"Exc",  organ:"P" },{type:"Exc",organ:"IG"}] },
      { label:"Prurido nasal",    hint:"Exc. P",    tags:[{type:"Exc",  organ:"P" }] },
      { label:"Obstrução nasal",  hint:"Estag. P",  tags:[{type:"Estag",organ:"P" }] },
      { label:"Coriza líquida",   hint:"Def. P",    tags:[{type:"Def",  organ:"P" }] },
    ]
  },
  { id:13, title:"Pele", type:"multiple", subtitle:"Selecione todos que se aplicam",
    options:[
      { label:"Normal",                 tags:[] },
      { label:"Dermatite",              hint:"Exc. IG",      tags:[{type:"Exc",organ:"IG"}] },
      { label:"Cravos e espinhas",      hint:"Exc. P/IG",    tags:[{type:"Exc",organ:"P"},{type:"Exc",organ:"IG"}] },
      { label:"Fibromialgia",           hint:"Def. P/BP/VB", tags:[{type:"Def",organ:"P"},{type:"Def",organ:"BP"},{type:"Def",organ:"VB"}] },
      { label:"Psoríase",               hint:"Exc. IG",      tags:[{type:"Exc",organ:"IG"}] },
      { label:"Envelhecimento precoce", hint:"Def. R",       tags:[{type:"Def",organ:"R" }] },
    ]
  },
  { id:14, title:"Olhos e Visão", type:"multiple", subtitle:"Selecione todos que se aplicam",
    options:[
      { label:"Normal",            tags:[] },
      { label:"Visão fraca",       hint:"Def. F",   tags:[{type:"Def",  organ:"F"}] },
      { label:"Visão turva",       hint:"Def. F",   tags:[{type:"Def",  organ:"F"}] },
      { label:"Olhos secos",       hint:"Def. F",   tags:[{type:"Def",  organ:"F"}] },
      { label:"Lacrimejamento",    hint:"Estag. F", tags:[{type:"Estag",organ:"F"}] },
      { label:"Tremor ocular",     hint:"Exc. F",   tags:[{type:"Exc",  organ:"F"}] },
      { label:"Vermelhidão ocular",hint:"Exc. C/F", tags:[{type:"Exc",  organ:"C"},{type:"Exc",organ:"F"}] },
    ]
  },
  { id:15, title:"Emoções — Raiva e Frustração", type:"multiple", subtitle:"Elemento Madeira (Fígado/VB) — selecione todos que se aplicam",
    options:[
      { label:"Equilibrado emocionalmente",           tags:[] },
      { label:"Irritabilidade frequente",             hint:"Exc. F",    tags:[{type:"Exc",  organ:"F"},{type:"element",element:"Madeira"}] },
      { label:"Explosões de raiva",                   hint:"Exc. F/VB", tags:[{type:"Exc",  organ:"F"},{type:"Exc",organ:"VB"},{type:"element",element:"Madeira"}] },
      { label:"Frustração constante",                 hint:"Estag. F",  tags:[{type:"Estag",organ:"F"},{type:"element",element:"Madeira"}] },
      { label:"Ressentimento antigo",                 hint:"Estag. F",  tags:[{type:"Estag",organ:"F"},{type:"element",element:"Madeira"}] },
      { label:"Impaciência",                          hint:"Exc. F",    tags:[{type:"Exc",  organ:"F"},{type:"element",element:"Madeira"}] },
      { label:"Dificuldade em tomar decisões",        hint:"Def. VB",   tags:[{type:"Def",  organ:"VB"},{type:"element",element:"Madeira"}] },
      { label:"Raiva contida (não expressa)",         hint:"Estag. F",  tags:[{type:"Estag",organ:"F"},{type:"element",element:"Madeira"}] },
      { label:"Sensação de injustiça",                hint:"Estag. F",  tags:[{type:"Estag",organ:"F"},{type:"element",element:"Madeira"}] },
    ]
  },
  { id:16, title:"Emoções — Alegria e Ansiedade", type:"multiple", subtitle:"Elemento Fogo (Coração/PC) — selecione todos que se aplicam",
    options:[
      { label:"Equilibrado emocionalmente",           tags:[] },
      { label:"Ansiedade constante",                  hint:"Exc. C",    tags:[{type:"Exc",organ:"C"},{type:"element",element:"Fogo"}] },
      { label:"Agitação mental",                      hint:"Exc. C",    tags:[{type:"Exc",organ:"C"},{type:"element",element:"Fogo"}] },
      { label:"Fala excessiva / compulsiva",          hint:"Exc. C",    tags:[{type:"Exc",organ:"C"},{type:"element",element:"Fogo"}] },
      { label:"Euforia inadequada",                   hint:"Exc. C",    tags:[{type:"Exc",organ:"C"},{type:"element",element:"Fogo"}] },
      { label:"Pânico / Crises de ansiedade",         hint:"Exc. C",    tags:[{type:"Exc",organ:"C"},{type:"Exc",organ:"CS"},{type:"element",element:"Fogo"}] },
      { label:"Falta de alegria / Apatia",            hint:"Def. C",    tags:[{type:"Def",organ:"C"},{type:"element",element:"Fogo"}] },
      { label:"Dificuldade de conexão emocional",     hint:"Def. C",    tags:[{type:"Def",organ:"C"},{type:"element",element:"Fogo"}] },
      { label:"Nervosismo",                           hint:"Exc. C",    tags:[{type:"Exc",organ:"C"},{type:"element",element:"Fogo"}] },
    ]
  },
  { id:17, title:"Emoções — Preocupação e Pensamento", type:"multiple", subtitle:"Elemento Terra (Baço/Estômago) — selecione todos que se aplicam",
    options:[
      { label:"Equilibrado emocionalmente",           tags:[] },
      { label:"Preocupação excessiva",                hint:"Def. BP",   tags:[{type:"Def",  organ:"BP"},{type:"element",element:"Terra"}] },
      { label:"Ruminação mental constante",           hint:"Def. BP",   tags:[{type:"Def",  organ:"BP"},{type:"element",element:"Terra"}] },
      { label:"Pensamento obsessivo",                 hint:"Def. BP",   tags:[{type:"Def",  organ:"BP"},{type:"element",element:"Terra"}] },
      { label:"Dificuldade em parar de pensar",       hint:"Def. BP",   tags:[{type:"Def",  organ:"BP"},{type:"element",element:"Terra"}] },
      { label:"Necessidade de controle",              hint:"Def. BP",   tags:[{type:"Def",  organ:"BP"},{type:"element",element:"Terra"}] },
      { label:"Preocupação com os outros (excesso)",  hint:"Def. BP",   tags:[{type:"Def",  organ:"BP"},{type:"element",element:"Terra"}] },
      { label:"Dificuldade de concentração",          hint:"Def. BP",   tags:[{type:"Def",  organ:"BP"},{type:"element",element:"Terra"}] },
      { label:"Pensamentos circulares sem solução",   hint:"Def. BP",   tags:[{type:"Def",  organ:"BP"},{type:"element",element:"Terra"}] },
    ]
  },
  { id:18, title:"Emoções — Tristeza e Melancolia", type:"multiple", subtitle:"Elemento Metal (Pulmão/IG) — selecione todos que se aplicam",
    options:[
      { label:"Equilibrado emocionalmente",           tags:[] },
      { label:"Tristeza profunda",                    hint:"Def. P",    tags:[{type:"Def",organ:"P"},{type:"element",element:"Metal"}] },
      { label:"Melancolia constante",                 hint:"Def. P",    tags:[{type:"Def",organ:"P"},{type:"element",element:"Metal"}] },
      { label:"Luto não processado",                  hint:"Def. P",    tags:[{type:"Def",organ:"P"},{type:"element",element:"Metal"}] },
      { label:"Choro fácil / frequente",              hint:"Def. P",    tags:[{type:"Def",organ:"P"},{type:"element",element:"Metal"}] },
      { label:"Sensação de vazio",                    hint:"Def. P",    tags:[{type:"Def",organ:"P"},{type:"element",element:"Metal"}] },
      { label:"Dificuldade em deixar ir / Apego",     hint:"Def. P/IG", tags:[{type:"Def",organ:"P"},{type:"Def",organ:"IG"},{type:"element",element:"Metal"}] },
      { label:"Pessimismo",                           hint:"Def. P",    tags:[{type:"Def",organ:"P"},{type:"element",element:"Metal"}] },
      { label:"Isolamento social",                    hint:"Def. P",    tags:[{type:"Def",organ:"P"},{type:"element",element:"Metal"}] },
    ]
  },
  { id:19, title:"Emoções — Medo e Insegurança", type:"multiple", subtitle:"Elemento Água (Rim/Bexiga) — selecione todos que se aplicam",
    options:[
      { label:"Equilibrado emocionalmente",           tags:[] },
      { label:"Medo constante / generalizado",        hint:"Def. R",    tags:[{type:"Def",organ:"R"},{type:"element",element:"Água"}] },
      { label:"Fobias específicas",                   hint:"Def. R",    tags:[{type:"Def",organ:"R"},{type:"element",element:"Água"}] },
      { label:"Insegurança profunda",                 hint:"Def. R",    tags:[{type:"Def",organ:"R"},{type:"element",element:"Água"}] },
      { label:"Paralisia por medo",                   hint:"Def. R",    tags:[{type:"Def",organ:"R"},{type:"element",element:"Água"}] },
      { label:"Medo de perder controle",              hint:"Def. R/B",  tags:[{type:"Def",organ:"R"},{type:"Def",organ:"B"},{type:"element",element:"Água"}] },
      { label:"Timidez excessiva",                    hint:"Def. R",    tags:[{type:"Def",organ:"R"},{type:"element",element:"Água"}] },
      { label:"Sensação de ameaça constante",         hint:"Def. R",    tags:[{type:"Def",organ:"R"},{type:"element",element:"Água"}] },
      { label:"Falta de força de vontade (Zhi)",      hint:"Def. R",    tags:[{type:"Def",organ:"R"},{type:"element",element:"Água"}] },
    ]
  },
];

const PROTOCOLS = {
  F: {
    Exc: { title:"Sedação do Fígado — Excesso de Yang / Calor", points:[
      {code:"F-2",   name:"Xing Jian",      note:"Ponto sedação — drena Fogo do Fígado"},
      {code:"F-3",   name:"Tai Chong",       note:"Yuan Source — regula Qi, acalma Yang"},
      {code:"VB-34", name:"Yang Ling Quan",  note:"Hui dos tendões — regula Madeira"},
      {code:"TA-5",  name:"Wai Guan",        note:"Dispersa Calor, move Qi"},
    ]},
    Def: { title:"Tonificação do Fígado — Deficiência de Yin/Sangue", points:[
      {code:"F-8",  name:"Qu Quan",      note:"Ponto tonificação — nutre Yin do Fígado"},
      {code:"F-3",  name:"Tai Chong",    note:"Yuan Source — fortalece Sangue"},
      {code:"BP-6", name:"San Yin Jiao", note:"Nutre Sangue e Yin (ponto maestro)"},
      {code:"R-3",  name:"Tai Xi",       note:"Tonifica Yin da Água para nutrir Madeira"},
    ]},
    Estag: { title:"Desobstrução do Fígado — Estagnação de Qi", points:[
      {code:"F-3",  name:"Tai Chong",     note:"Move Qi estagnado — ponto principal"},
      {code:"PC-6", name:"Nei Guan",      note:"Abre tórax, move Qi e Xue"},
      {code:"TA-6", name:"Zhi Gou",       note:"Move Qi no aquecedor médio"},
      {code:"VB-34",name:"Yang Ling Quan",note:"Regula Qi da Vesícula Biliar"},
      {code:"F-14", name:"Qi Men",        note:"Mu alarm — libera estagnação hepática"},
    ]}
  },
  VB: {
    Exc: { title:"Sedação da Vesícula Biliar — Excesso de Calor/Yang", points:[
      {code:"VB-43",name:"Xia Xi",         note:"Ponto sedação — drena Calor da VB"},
      {code:"VB-44",name:"Zu Qiao Yin",    note:"Well point — drena excesso"},
      {code:"VB-34",name:"Yang Ling Quan", note:"He-sea — regula VB"},
      {code:"F-2",  name:"Xing Jian",      note:"Drena Fogo do par Fígado/VB"},
    ]},
    Def: { title:"Tonificação da Vesícula Biliar — Deficiência de Qi", points:[
      {code:"VB-43",name:"Xia Xi",         note:"Tonifica a Vesícula Biliar"},
      {code:"VB-40",name:"Qiu Xu",         note:"Yuan Source — fortalece VB"},
      {code:"VB-34",name:"Yang Ling Quan", note:"Fortalece tendões e articulações"},
    ]},
    Estag: { title:"Desobstrução da Vesícula Biliar — Estagnação de Qi", points:[
      {code:"VB-34",name:"Yang Ling Quan", note:"Move Qi no canal"},
      {code:"VB-21",name:"Jian Jing",      note:"Libera ombro e pescoço"},
      {code:"VB-20",name:"Feng Chi",       note:"Dispersa vento, libera cervical"},
      {code:"F-3",  name:"Tai Chong",      note:"Par distal — regula Madeira"},
    ]}
  },
  C: {
    Exc: { title:"Sedação do Coração — Excesso de Fogo", points:[
      {code:"C-8",  name:"Shao Fu",    note:"Ponto sedação — drena Fogo do Coração"},
      {code:"C-7",  name:"Shen Men",   note:"Yuan Source — acalma Shen"},
      {code:"PC-6", name:"Nei Guan",   note:"Acalma Coração e Mente"},
      {code:"ID-2", name:"Qian Gu",    note:"Drena Calor do par C/ID"},
    ]},
    Def: { title:"Tonificação do Coração — Deficiência de Qi/Sangue", points:[
      {code:"C-9",  name:"Shao Chong", note:"Ponto tonificação — nutre Coração"},
      {code:"C-7",  name:"Shen Men",   note:"Yuan Source — fortalece Shen"},
      {code:"PC-6", name:"Nei Guan",   note:"Nutre e protege o Coração"},
      {code:"BP-6", name:"San Yin Jiao",note:"Nutre Xue do Coração"},
      {code:"E-36", name:"Zu San Li",  note:"Fortalece produção de Qi e Xue"},
    ]}
  },
  ID: {
    Exc: { title:"Sedação do Intestino Delgado — Excesso de Calor", points:[
      {code:"ID-2", name:"Qian Gu",  note:"Ponto sedação — drena Calor do ID"},
      {code:"ID-8", name:"Xiao Hai", note:"He-sea — regula o Intestino Delgado"},
      {code:"C-8",  name:"Shao Fu",  note:"Drena Fogo do par C/ID"},
    ]},
    Def: { title:"Tonificação do Intestino Delgado — Deficiência de Qi", points:[
      {code:"ID-3", name:"Hou Xi",      note:"Ponto tonificação — fortalece ID"},
      {code:"E-36", name:"Zu San Li",   note:"Fortalece Qi digestivo"},
      {code:"BP-6", name:"San Yin Jiao",note:"Regula intestinos"},
    ]}
  },
  CS: {
    Exc: { title:"Sedação do Pericárdio — Excesso de Fogo", points:[
      {code:"PC-7", name:"Da Ling",  note:"Ponto sedação — drena Calor do PC"},
      {code:"PC-8", name:"Lao Gong", note:"Drena Fogo intenso"},
      {code:"C-8",  name:"Shao Fu",  note:"Complementa sedação do Fogo"},
    ]},
    Def: { title:"Tonificação do Pericárdio — Deficiência de Yin/Sangue", points:[
      {code:"PC-9", name:"Zhong Chong",note:"Ponto tonificação do Pericárdio"},
      {code:"PC-6", name:"Nei Guan",   note:"Luo — nutre e protege o Coração"},
      {code:"BP-6", name:"San Yin Jiao",note:"Nutre Yin e Sangue"},
    ]}
  },
  TA: {
    Exc: { title:"Sedação do Triplo Aquecedor — Excesso de Calor", points:[
      {code:"TA-2",  name:"Yemen",     note:"Ponto sedação — drena Calor do TA"},
      {code:"TA-10", name:"Tian Jing", note:"He-sea — regula Triplo Aquecedor"},
    ]},
    Def: { title:"Tonificação do Triplo Aquecedor — Deficiência de Qi/Yang", points:[
      {code:"TA-3", name:"Zhong Zhu", note:"Ponto tonificação — fortalece TA"},
      {code:"TA-4", name:"Yang Chi",  note:"Yuan Source — regula energia original"},
      {code:"Du-4", name:"Ming Men",  note:"Fortalece Yang original"},
    ]}
  },
  BP: {
    Exc: { title:"Sedação do Baço-Pâncreas — Excesso de Umidade", points:[
      {code:"BP-5", name:"Shang Qiu",     note:"Ponto sedação — drena Umidade do BP"},
      {code:"BP-9", name:"Yin Ling Quan", note:"Drena Umidade — ponto forte"},
      {code:"E-40", name:"Feng Long",     note:"Transforma Fleuma e Umidade"},
      {code:"BP-6", name:"San Yin Jiao",  note:"Regula BP e transforma Umidade"},
    ]},
    Def: { title:"Tonificação do Baço-Pâncreas — Deficiência de Qi/Yang", points:[
      {code:"BP-2", name:"Da Du",      note:"Ponto tonificação — fortalece BP"},
      {code:"BP-3", name:"Tai Bai",    note:"Yuan Source — tonifica BP"},
      {code:"E-36", name:"Zu San Li",  note:"Mestre do abdômen — fortalece BP/E"},
      {code:"Ren-12",name:"Zhong Wan", note:"Mu alarm E — tonifica digestão"},
    ]}
  },
  E: {
    Exc: { title:"Sedação do Estômago — Excesso de Calor/Fogo", points:[
      {code:"E-45",  name:"Li Dui",    note:"Ponto sedação — drena Fogo do Estômago"},
      {code:"E-44",  name:"Nei Ting",  note:"Drena Calor do Estômago"},
      {code:"IG-11", name:"Qu Chi",    note:"Drena Calor, regula Metal/Terra"},
      {code:"E-34",  name:"Liang Qiu", note:"Xi-cleft — dor aguda do Estômago"},
    ]},
    Def: { title:"Tonificação do Estômago — Deficiência de Qi/Yin", points:[
      {code:"E-41",  name:"Jie Xi",    note:"Ponto tonificação do Estômago"},
      {code:"E-36",  name:"Zu San Li", note:"He-sea — ponto mestre do Estômago"},
      {code:"BP-3",  name:"Tai Bai",   note:"Yuan Source BP — apoia Estômago"},
      {code:"Ren-12",name:"Zhong Wan", note:"Mu alarm E — tonifica digestão"},
    ]}
  },
  P: {
    Exc: { title:"Sedação do Pulmão — Excesso de Qi/Calor/Fleuma", points:[
      {code:"P-5",   name:"Chi Ze",    note:"Ponto sedação — drena Calor do Pulmão"},
      {code:"P-6",   name:"Kong Zui",  note:"Xi-cleft — condições agudas do P"},
      {code:"IG-11", name:"Qu Chi",    note:"Drena Calor, regula exterior"},
      {code:"E-40",  name:"Feng Long", note:"Transforma Fleuma do Pulmão"},
    ]},
    Def: { title:"Tonificação do Pulmão — Deficiência de Qi/Yin", points:[
      {code:"P-9",   name:"Tai Yuan",   note:"Yuan Source / Tonificação — nutre P"},
      {code:"P-7",   name:"Lie Que",    note:"Luo — abre superfície, regula P"},
      {code:"E-36",  name:"Zu San Li",  note:"Fortalece produção de Qi de P"},
      {code:"Ren-17",name:"Shan Zhong", note:"Mu alarm PC / Reúne Qi ancestral"},
    ]},
    Estag: { title:"Desobstrução do Pulmão — Estagnação de Qi", points:[
      {code:"P-7",  name:"Lie Que",    note:"Abre e descende Qi do Pulmão"},
      {code:"IG-4", name:"He Gu",      note:"Par distal — regula Metal"},
      {code:"E-40", name:"Feng Long",  note:"Transforma obstrução por Fleuma"},
    ]}
  },
  IG: {
    Exc: { title:"Sedação do Intestino Grosso — Excesso de Calor/Umidade", points:[
      {code:"IG-2",  name:"Er Jian",  note:"Ponto sedação — drena Calor do IG"},
      {code:"IG-11", name:"Qu Chi",   note:"He-sea — drena Calor e Umidade"},
      {code:"IG-4",  name:"He Gu",    note:"Yuan Source — regula exterior/interior"},
      {code:"E-25",  name:"Tian Shu", note:"Mu alarm IG — regula intestinos"},
    ]},
    Def: { title:"Tonificação do Intestino Grosso — Deficiência de Qi/Yang", points:[
      {code:"IG-11", name:"Qu Chi",       note:"Tonifica e regula IG"},
      {code:"IG-4",  name:"He Gu",        note:"Yuan Source — fortalece IG"},
      {code:"E-36",  name:"Zu San Li",    note:"Fortalece Qi do Metal/Terra"},
      {code:"BP-6",  name:"San Yin Jiao", note:"Regula intestinos"},
    ]}
  },
  R: {
    Exc: { title:"Sedação do Rim — Calor por Deficiência de Yin", points:[
      {code:"R-2",   name:"Ran Gu",    note:"Ponto sedação — drena Fogo do Rim"},
      {code:"R-1",   name:"Yong Quan", note:"Well point — drena Calor extremo"},
      {code:"Be-66", name:"Zu Tong Gu",note:"Ponto sedação do par Rim/Bexiga"},
    ]},
    Def: { title:"Tonificação do Rim — Deficiência de Yin/Yang/Jing", points:[
      {code:"R-7",   name:"Fu Liu",    note:"Ponto tonificação — fortalece Yang do R"},
      {code:"R-3",   name:"Tai Xi",    note:"Yuan Source — nutre Yin e Essência"},
      {code:"Be-23", name:"Shen Shu",  note:"Shu dorsal — tonifica o Rim"},
      {code:"Du-4",  name:"Ming Men",  note:"Fortalece o Fogo da Vida"},
      {code:"E-36",  name:"Zu San Li", note:"Fortalece base energética"},
    ]}
  },
  B: {
    Exc: { title:"Sedação da Bexiga — Excesso de Calor/Umidade", points:[
      {code:"Be-66", name:"Zu Tong Gu",note:"Ponto sedação — drena Calor da Bexiga"},
      {code:"Be-40", name:"Wei Zhong", note:"He-sea — regula Be, alivia lombar"},
      {code:"Be-67", name:"Zhi Yin",   note:"Well point — drena excesso"},
      {code:"R-3",   name:"Tai Xi",    note:"Par Yin — regula Bexiga"},
    ]},
    Def: { title:"Tonificação da Bexiga — Deficiência de Qi/Yang", points:[
      {code:"Be-67", name:"Zhi Yin",   note:"Ponto tonificação — fortalece Be"},
      {code:"Be-40", name:"Wei Zhong", note:"He-sea — fortalece lombar/Be"},
      {code:"Be-23", name:"Shen Shu",  note:"Shu dorsal do Rim — suporte Yang"},
      {code:"R-7",   name:"Fu Liu",    note:"Tonifica Yang do par R/Be"},
    ]},
    Estag: { title:"Desobstrução da Bexiga — Estagnação de Qi", points:[
      {code:"Be-40", name:"Wei Zhong",     note:"He-sea — libera canal da Bexiga"},
      {code:"Be-60", name:"Kun Lun",       note:"Libera canal, alivia lombar/ciática"},
      {code:"Be-57", name:"Cheng Shan",    note:"Câimbras, dor no gastrocnêmio"},
      {code:"VB-34", name:"Yang Ling Quan",note:"Tendões e articulações"},
    ]}
  }
};

function Pentagram({ organScores, elementScores }) {
  const cx = 150, cy = 150, r = 92;
  const pt = (angle, radius = r) => ({
    x: cx + radius * Math.cos(angle * Math.PI / 180),
    y: cy + radius * Math.sin(angle * Math.PI / 180),
  });
  const getScore = (el) => {
    const organs = ELEMENTS[el].organs;
    return organs.reduce((s, o) => {
      const sc = organScores[o] || { Exc:0, Def:0, Estag:0 };
      return s + sc.Exc + sc.Def + sc.Estag;
    }, 0) + (elementScores[el] || 0);
  };
  const max = Math.max(...Object.keys(ELEMENTS).map(getScore), 3);

  return (
    <svg viewBox="0 0 300 300" style={{ width:"100%", maxWidth:260, display:"block", margin:"0 auto" }}>
      <circle cx={cx} cy={cy} r={120} fill="none" stroke="#0e1e30" strokeWidth="1" />
      {PENTA.map((p, i) => {
        const n = PENTA[(i+1)%5];
        const a = pt(p.angle), b = pt(n.angle);
        return <line key={"s"+i} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke="#152535" strokeWidth="1.5" strokeDasharray="5,4" />;
      })}
      {PENTA.map((p, i) => {
        const n = PENTA[(i+2)%5];
        const a = pt(p.angle), b = pt(n.angle);
        return <line key={"k"+i} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke="#0d1a28" strokeWidth="1" />;
      })}
      <circle cx={cx} cy={cy} r={3.5} fill="#1e3050" />
      {PENTA.map(({ element, angle }) => {
        const p = pt(angle);
        const score = getScore(element);
        const ratio = score / max;
        const size = 22 + ratio * 20;
        const el = ELEMENTS[element];
        return (
          <g key={element}>
            <circle cx={p.x} cy={p.y} r={size + 6} fill={el.color} opacity={0.04 + ratio * 0.08} />
            <circle cx={p.x} cy={p.y} r={size} fill={el.dark} stroke={el.color} strokeWidth={1.5 + ratio * 1.5} />
            <text x={p.x} y={p.y + 1} textAnchor="middle" dominantBaseline="middle"
              fill={el.color} fontSize={15} fontWeight="bold" fontFamily="serif">{el.symbol}</text>
            {score > 0 && (
              <text x={p.x} y={p.y + 14} textAnchor="middle" fill={el.color} fontSize={9} opacity={0.85}>{score}</text>
            )}
            <text x={p.x} y={p.y + size + 10} textAnchor="middle" fill={el.color} fontSize={7} letterSpacing="0.5"
              fontFamily="sans-serif">{element.toUpperCase()}</text>
          </g>
        );
      })}
    </svg>
  );
}

export default function App() {
  const [step, setStep]           = useState(0);
  const [answers, setAnswers]     = useState({});
  const [patientName, setName]    = useState("");
  const [patientHistory, setHistory] = useState([]);
  const [showHistory, setShowHistory] = useState(false);
  const [currentDate, setCurrentDate] = useState(new Date().toISOString());
  const TOTAL = QUESTIONS.length;

  // Add print styles
  useState(() => {
    const style = document.createElement('style');
    style.textContent = `
      @media print {
        body { background: white !important; }
        button { display: none !important; }
        .no-print { display: none !important; }
        @page { margin: 1cm; }
      }
    `;
    document.head.appendChild(style);
    return () => document.head.removeChild(style);
  }, []);

  // Load history from localStorage on mount
  useState(() => {
    try {
      const saved = localStorage.getItem('acupuntura_history');
      if (saved) setHistory(JSON.parse(saved));
    } catch (e) {
      console.error('Error loading history:', e);
    }
  }, []);

  const saveToHistory = () => {
    const record = {
      id: Date.now(),
      date: currentDate,
      name: patientName || "Sem nome",
      answers,
      organScores,
      elementScores,
      protocols,
      topElement
    };
    const newHistory = [record, ...patientHistory].slice(0, 50); // Keep last 50
    setHistory(newHistory);
    try {
      localStorage.setItem('acupuntura_history', JSON.stringify(newHistory));
    } catch (e) {
      console.error('Error saving history:', e);
    }
  };

  const loadFromHistory = (record) => {
    setName(record.name);
    setAnswers(record.answers);
    setCurrentDate(record.date);
    setStep(TOTAL + 1);
    setShowHistory(false);
  };

  const deleteFromHistory = (id) => {
    const newHistory = patientHistory.filter(r => r.id !== id);
    setHistory(newHistory);
    try {
      localStorage.setItem('acupuntura_history', JSON.stringify(newHistory));
    } catch (e) {
      console.error('Error deleting from history:', e);
    }
  };

  const exportToJSON = () => {
    const data = {
      patient: patientName,
      date: currentDate,
      answers,
      organScores,
      elementScores,
      protocols,
      topElement
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `acupuntura_${patientName.replace(/\s/g, '_')}_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const exportToCSV = () => {
    const rows = [
      ['Paciente', patientName],
      ['Data', new Date(currentDate).toLocaleDateString('pt-BR')],
      ['Elemento Predominante', topElement],
      [''],
      ['Protocolo', 'Órgão', 'Padrão', 'Score', 'Pontos']
    ];
    
    protocols.forEach(p => {
      const points = p.points.map(pt => `${pt.code} (${pt.name})`).join('; ');
      rows.push([p.title, p.organName, PT_LABELS[p.pattern], p.score, points]);
    });

    const csv = rows.map(r => r.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `acupuntura_${patientName.replace(/\s/g, '_')}_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const toggle = (qId, idx, single) => {
    setAnswers(prev => {
      const curr = prev[qId] || [];
      if (single) return { ...prev, [qId]: [idx] };
      return {
        ...prev,
        [qId]: curr.includes(idx) ? curr.filter(i => i !== idx) : [...curr, idx],
      };
    });
  };

  const { organScores, elementScores } = useMemo(() => {
    const os = {};
    Object.keys(ORGAN_INFO).forEach(o => os[o] = { Exc:0, Def:0, Estag:0 });
    const es = { Madeira:0, Fogo:0, Terra:0, Metal:0, Água:0 };
    QUESTIONS.forEach(q => {
      (answers[q.id] || []).forEach(idx => {
        (q.options[idx]?.tags || []).forEach(t => {
          if (t.type === "element") es[t.element]++;
          else if (t.organ) os[t.organ][t.type]++;
        });
      });
    });
    return { organScores: os, elementScores: es };
  }, [answers]);

  const protocols = useMemo(() => {
    const list = [];
    Object.entries(organScores).forEach(([organ, s]) => {
      ["Exc","Def","Estag"].forEach(p => {
        if (s[p] > 0 && PROTOCOLS[organ]?.[p]) {
          list.push({ organ, pattern:p, score:s[p],
            element: ORGAN_INFO[organ].element,
            organName: ORGAN_INFO[organ].name,
            ...PROTOCOLS[organ][p] });
        }
      });
    });
    return list.sort((a,b) => b.score - a.score).slice(0, 10);
  }, [organScores]);

  const topElement = useMemo(() => {
    const sc = { ...elementScores };
    Object.entries(organScores).forEach(([o, s]) => {
      const el = ORGAN_INFO[o].element;
      sc[el] = (sc[el] || 0) + s.Exc + s.Def + s.Estag;
    });
    return Object.entries(sc).sort((a,b)=>b[1]-a[1])[0]?.[0] || "Fogo";
  }, [organScores, elementScores]);

  const accent = ELEMENTS[topElement]?.color || GOLD;

  const S = {
    card: (extra={}) => ({ background:CARD, border:`1px solid ${BORDER}`, borderRadius:12, ...extra }),
    tag:  (c) => ({ background:`${c}18`, color:c, fontSize:"0.6rem", padding:"2px 8px", borderRadius:20, fontWeight:600, letterSpacing:"0.05em" }),
  };

  const PT_COLORS = { Exc:"#f87171", Def:"#60a5fa", Estag:"#fbbf24" };
  const PT_LABELS = { Exc:"EXCESSO", Def:"DEFICIÊNCIA", Estag:"ESTAGNAÇÃO" };
  const PT_VERBS  = { Exc:"Sedar", Def:"Tonificar", Estag:"Desobstruir" };

  if (step === 0) return (
    <div style={{ background:BG, minHeight:"100vh", fontFamily:"sans-serif", color:"white" }}>
      <div style={{ maxWidth:480, margin:"0 auto", padding:"2rem 1.5rem", display:"flex", flexDirection:"column", gap:"1.4rem" }}>
        <div style={{ textAlign:"center", paddingTop:"1rem" }}>
          <div style={{ fontSize:"2.8rem" }}>針</div>
          <h1 style={{ color:GOLD, fontSize:"1.25rem", letterSpacing:"0.15em", margin:"0.4rem 0 0.3rem" }}>
            AVALIAÇÃO DE ACUPUNTURA
          </h1>
          <p style={{ color:"#4a7090", fontSize:"0.78rem", margin:0 }}>Instituto Nilza Ferreira — IBEEA</p>
        </div>

        <div style={{ display:"flex", justifyContent:"center", gap:"0.7rem", flexWrap:"wrap" }}>
          {Object.entries(ELEMENTS).map(([name, el]) => (
            <div key={name} style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:"0.3rem" }}>
              <div style={{ width:42, height:42, borderRadius:"50%", background:el.dark, border:`2px solid ${el.color}`, display:"flex", alignItems:"center", justifyContent:"center", fontSize:"1.2rem", color:el.color }}>{el.symbol}</div>
              <div style={{ fontSize:"0.6rem", color:el.color, letterSpacing:"0.08em" }}>{name.toUpperCase()}</div>
            </div>
          ))}
        </div>

        <div style={S.card({ padding:"1.5rem" })}>
          <label style={{ display:"block", marginBottom:"0.7rem", fontSize:"0.75rem", color:"#6b8aaa", letterSpacing:"0.05em" }}>NOME DO PACIENTE</label>
          <input value={patientName} onChange={e => setName(e.target.value)} placeholder="Digite o nome"
            style={{ width:"100%", background:"#060d18", border:`1px solid ${BORDER}`, borderRadius:8, padding:"0.75rem", color:"white", fontSize:"0.95rem" }} />
        </div>

        <button onClick={() => setStep(1)}
          style={{ background:`linear-gradient(135deg, ${accent}22, ${accent}08)`, border:`1px solid ${accent}`, color:accent, padding:"1rem", borderRadius:10, fontSize:"0.85rem", fontWeight:600, letterSpacing:"0.1em", cursor:"pointer" }}>
          INICIAR AVALIAÇÃO →
        </button>

        {patientHistory.length > 0 && (
          <button onClick={() => setShowHistory(!showHistory)}
            style={{ background:"transparent", border:`1px solid ${BORDER}`, color:"#6b8aaa", padding:"0.9rem", borderRadius:10, fontSize:"0.8rem", fontWeight:600, letterSpacing:"0.08em", cursor:"pointer" }}>
            {showHistory ? '✕ FECHAR' : `📋 HISTÓRICO (${patientHistory.length})`}
          </button>
        )}

        {showHistory && (
          <div style={S.card({ padding:"1.2rem" })}>
            <h3 style={{ margin:"0 0 1rem", fontSize:"0.85rem", color:GOLD, letterSpacing:"0.1em" }}>AVALIAÇÕES ANTERIORES</h3>
            <div style={{ display:"flex", flexDirection:"column", gap:"0.6rem", maxHeight:400, overflowY:"auto" }}>
              {patientHistory.map(rec => (
                <div key={rec.id} style={{ background:"#060d18", borderRadius:8, padding:"0.8rem", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:"0.85rem", color:"white", fontWeight:600 }}>{rec.name}</div>
                    <div style={{ fontSize:"0.65rem", color:"#6b8aaa", marginTop:"0.2rem" }}>
                      {new Date(rec.date).toLocaleDateString('pt-BR')} • {rec.protocols?.length || 0} protocolos
                    </div>
                  </div>
                  <div style={{ display:"flex", gap:"0.5rem" }}>
                    <button onClick={() => loadFromHistory(rec)} style={{ background:ELEMENTS[rec.topElement]?.color + "20", color:ELEMENTS[rec.topElement]?.color, border:"none", padding:"0.4rem 0.7rem", borderRadius:6, fontSize:"0.7rem", cursor:"pointer", fontWeight:600 }}>
                      ABRIR
                    </button>
                    <button onClick={() => deleteFromHistory(rec.id)} style={{ background:"#f8717120", color:"#f87171", border:"none", padding:"0.4rem 0.7rem", borderRadius:6, fontSize:"0.7rem", cursor:"pointer" }}>
                      ✕
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <div style={{ fontSize:"0.65rem", color:"#4a5a70", textAlign:"center", lineHeight:1.6, padding:"0.5rem" }}>
          Este questionário identifica padrões de Excesso, Deficiência e Estagnação nos 12 meridianos principais através de 14 categorias diagnósticas. Ao final, protocolos de acupuntura serão gerados automaticamente com base nos padrões identificados.
        </div>
      </div>
    </div>
  );

  if (step <= TOTAL) {
    const q = QUESTIONS[step - 1];
    const selected = answers[q.id] || [];
    const canNext = selected.length > 0;

    return (
      <div style={{ background:BG, minHeight:"100vh", fontFamily:"sans-serif", color:"white" }}>
        <div style={{ maxWidth:520, margin:"0 auto", padding:"1.5rem" }}>
          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:"1.5rem" }}>
            <button onClick={() => setStep(s => s - 1)} style={{ background:"transparent", border:"none", color:"#6b8aaa", fontSize:"1.5rem", cursor:"pointer" }}>←</button>
            <div style={{ textAlign:"center" }}>
              <div style={{ fontSize:"0.65rem", color:"#4a7090", letterSpacing:"0.1em" }}>QUESTÃO {step}/{TOTAL}</div>
              {patientName && <div style={{ fontSize:"0.7rem", color:GOLD, marginTop:"0.2rem" }}>{patientName}</div>}
            </div>
            <div style={{ width:30 }}></div>
          </div>

          <div style={{ background:"#0b1625", height:4, borderRadius:2, marginBottom:"1.5rem", overflow:"hidden" }}>
            <div style={{ background:`linear-gradient(90deg, ${accent}, ${accent}aa)`, height:"100%", width:`${(step/TOTAL)*100}%`, transition:"width 0.3s ease" }} />
          </div>

          <div style={S.card({ padding:"1.5rem 1.5rem 1.2rem", marginBottom:"1.2rem" })}>
            <h2 style={{ margin:"0 0 0.5rem", fontSize:"1.2rem", color:accent }}>{q.title}</h2>
            <p style={{ margin:0, fontSize:"0.75rem", color:"#6b8aaa", lineHeight:1.5 }}>{q.subtitle}</p>
          </div>

          <div style={{ display:"flex", flexDirection:"column", gap:"0.7rem", marginBottom:"1.5rem" }}>
            {q.options.map((opt, idx) => {
              const isSelected = selected.includes(idx);
              const tags = opt.tags || [];
              const hasTags = tags.length > 0 && tags.some(t => t.type || t.element);
              
              return (
                <button key={idx} onClick={() => toggle(q.id, idx, q.type === "single")}
                  style={{
                    background: isSelected ? `${accent}15` : CARD,
                    border: `1px solid ${isSelected ? accent : BORDER}`,
                    borderRadius:10, padding:"0.95rem 1.1rem", textAlign:"left", cursor:"pointer",
                    transition:"all 0.2s", display:"flex", flexDirection:"column", gap:"0.4rem"
                  }}>
                  <div style={{ display:"flex", alignItems:"center", gap:"0.7rem" }}>
                    <div style={{ width:18, height:18, borderRadius:q.type === "single" ? "50%" : 4, border:`2px solid ${isSelected ? accent : "#2a3d54"}`, background:isSelected ? accent : "transparent", flexShrink:0, transition:"all 0.2s" }} />
                    <div style={{ flex:1, fontSize:"0.85rem", color:isSelected ? "white" : "#b8c9de" }}>{opt.label}</div>
                  </div>
                  {hasTags && (
                    <div style={{ display:"flex", gap:"0.4rem", flexWrap:"wrap", marginLeft:"1.6rem" }}>
                      {tags.map((t, i) => {
                        if (t.element) return <span key={i} style={S.tag(ELEMENTS[t.element].color)}>{t.element}</span>;
                        if (t.type && t.organ) {
                          const color = PT_COLORS[t.type];
                          return <span key={i} style={S.tag(color)}>{PT_LABELS[t.type]} {t.organ}</span>;
                        }
                        return null;
                      })}
                      {opt.hint && <span style={{ fontSize:"0.6rem", color:"#4a7090", fontStyle:"italic" }}>→ {opt.hint}</span>}
                    </div>
                  )}
                </button>
              );
            })}
          </div>

          <button onClick={() => setStep(s => s + 1)} disabled={!canNext}
            style={{
              width:"100%", background: canNext ? `linear-gradient(135deg, ${accent}22, ${accent}08)` : "#0d1a28",
              border:`1px solid ${canNext ? accent : "#1a2d44"}`, color: canNext ? accent : "#2a3d54",
              padding:"1rem", borderRadius:10, fontSize:"0.85rem", fontWeight:600, letterSpacing:"0.1em",
              cursor: canNext ? "pointer" : "not-allowed", transition:"all 0.2s"
            }}>
            {step === TOTAL ? "GERAR PROTOCOLOS" : "PRÓXIMA →"}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ background:BG, minHeight:"100vh", fontFamily:"sans-serif", color:"white", paddingBottom:"3rem" }}>
      <div style={{ maxWidth:700, margin:"0 auto", padding:"1.5rem" }}>
        <div style={{ textAlign:"center", marginBottom:"2rem" }}>
          <div style={{ fontSize:"2rem" }}>針</div>
          <h1 style={{ color:GOLD, fontSize:"1.4rem", letterSpacing:"0.12em", margin:"0.5rem 0 0.3rem" }}>PROTOCOLOS DE ACUPUNTURA</h1>
          {patientName && <p style={{ color:accent, fontSize:"0.9rem", margin:"0.3rem 0 0" }}>{patientName}</p>}
          <p style={{ color:"#4a7090", fontSize:"0.7rem", margin:"0.5rem 0 0" }}>Instituto Nilza Ferreira — Avaliação Completa</p>
        </div>

        <div style={S.card({ padding:"2rem 1.5rem", marginBottom:"1.5rem" })}>
          <h3 style={{ margin:"0 0 1.2rem", fontSize:"0.85rem", color:GOLD, letterSpacing:"0.1em", textAlign:"center" }}>MAPEAMENTO DOS CINCO ELEMENTOS</h3>
          <Pentagram organScores={organScores} elementScores={elementScores} />
          <div style={{ marginTop:"1.5rem", textAlign:"center" }}>
            <div style={{ fontSize:"0.65rem", color:"#6b8aaa", marginBottom:"0.5rem" }}>ELEMENTO PREDOMINANTE</div>
            <div style={{ display:"inline-flex", alignItems:"center", gap:"0.6rem", background:ELEMENTS[topElement].dark, border:`1px solid ${ELEMENTS[topElement].color}`, borderRadius:20, padding:"0.5rem 1.2rem" }}>
              <span style={{ fontSize:"1.2rem" }}>{ELEMENTS[topElement].symbol}</span>
              <span style={{ color:ELEMENTS[topElement].color, fontWeight:600, letterSpacing:"0.1em" }}>{topElement.toUpperCase()}</span>
            </div>
          </div>
        </div>

        <div style={S.card({ padding:"1.5rem", marginBottom:"1.5rem" })}>
          <h3 style={{ margin:"0 0 1rem", fontSize:"0.85rem", color:GOLD, letterSpacing:"0.1em" }}>SCORES POR MERIDIANO</h3>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill, minmax(140px, 1fr))", gap:"0.7rem" }}>
            {Object.entries(organScores).filter(([_, s]) => s.Exc + s.Def + s.Estag > 0).sort((a,b) => {
              const sumA = a[1].Exc + a[1].Def + a[1].Estag;
              const sumB = b[1].Exc + b[1].Def + b[1].Estag;
              return sumB - sumA;
            }).map(([organ, s]) => {
              const info = ORGAN_INFO[organ];
              const el = ELEMENTS[info.element];
              return (
                <div key={organ} style={{ background:el.dark, border:`1px solid ${el.color}40`, borderRadius:8, padding:"0.7rem" }}>
                  <div style={{ display:"flex", alignItems:"center", gap:"0.4rem", marginBottom:"0.5rem" }}>
                    <span style={{ fontSize:"1rem", color:el.color }}>{el.symbol}</span>
                    <span style={{ fontSize:"0.75rem", color:el.color, fontWeight:600 }}>{info.abbr}</span>
                  </div>
                  <div style={{ fontSize:"0.6rem", color:"#6b8aaa", marginBottom:"0.4rem" }}>{info.name}</div>
                  <div style={{ display:"flex", gap:"0.3rem", flexWrap:"wrap" }}>
                    {s.Exc > 0 && <span style={{ ...S.tag(PT_COLORS.Exc), fontSize:"0.55rem" }}>Exc {s.Exc}</span>}
                    {s.Def > 0 && <span style={{ ...S.tag(PT_COLORS.Def), fontSize:"0.55rem" }}>Def {s.Def}</span>}
                    {s.Estag > 0 && <span style={{ ...S.tag(PT_COLORS.Estag), fontSize:"0.55rem" }}>Est {s.Estag}</span>}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div>
          <h3 style={{ margin:"0 0 1rem", fontSize:"0.85rem", color:GOLD, letterSpacing:"0.1em", textAlign:"center" }}>
            PROTOCOLOS RECOMENDADOS (TOP {protocols.length})
          </h3>
          {protocols.length === 0 && (
            <div style={S.card({ padding:"2rem", textAlign:"center" })}>
              <p style={{ color:"#6b8aaa", fontSize:"0.85rem" }}>Nenhum padrão significativo identificado. Refaça a avaliação ou consulte um profissional.</p>
            </div>
          )}
          {protocols.map((p, idx) => {
            const el = ELEMENTS[p.element];
            const ptColor = PT_COLORS[p.pattern];
            return (
              <div key={idx} style={S.card({ padding:"1.3rem", marginBottom:"1rem", borderLeft:`4px solid ${ptColor}` })}>
                <div style={{ display:"flex", alignItems:"flex-start", gap:"0.8rem", marginBottom:"1rem" }}>
                  <div style={{ fontSize:"1.5rem", color:el.color, lineHeight:1 }}>{el.symbol}</div>
                  <div style={{ flex:1 }}>
                    <div style={{ display:"flex", alignItems:"center", gap:"0.5rem", flexWrap:"wrap", marginBottom:"0.3rem" }}>
                      <span style={S.tag(ptColor)}>{PT_VERBS[p.pattern].toUpperCase()}</span>
                      <span style={S.tag(el.color)}>{p.organName} ({p.organ})</span>
                      <span style={{ fontSize:"0.7rem", color:"#4a7090" }}>Score: {p.score}</span>
                    </div>
                    <h4 style={{ margin:"0.4rem 0 0", fontSize:"0.85rem", color:"white", fontWeight:600 }}>{p.title}</h4>
                  </div>
                </div>

                <div style={{ display:"flex", flexDirection:"column", gap:"0.6rem" }}>
                  {p.points.map((pt, i) => (
                    <div key={i} style={{ background:"#060d18", borderRadius:6, padding:"0.7rem 0.9rem", display:"flex", gap:"0.8rem", alignItems:"flex-start" }}>
                      <div style={{ background:ptColor + "20", color:ptColor, fontSize:"0.7rem", fontWeight:700, padding:"0.3rem 0.6rem", borderRadius:5, minWidth:48, textAlign:"center" }}>
                        {pt.code}
                      </div>
                      <div style={{ flex:1 }}>
                        <div style={{ fontSize:"0.8rem", color:"white", fontWeight:600, marginBottom:"0.2rem" }}>{pt.name}</div>
                        <div style={{ fontSize:"0.68rem", color:"#6b8aaa", lineHeight:1.4 }}>{pt.note}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        <div style={{ display:"flex", flexDirection:"column", gap:"0.8rem", marginTop:"2rem" }}>
          <div style={{ display:"flex", gap:"0.8rem" }}>
            <button onClick={() => { setStep(0); setAnswers({}); setCurrentDate(new Date().toISOString()); }}
              style={{ flex:1, background:"transparent", border:`1px solid ${BORDER}`, color:"#6b8aaa", padding:"0.9rem", borderRadius:10, fontSize:"0.8rem", fontWeight:600, letterSpacing:"0.08em", cursor:"pointer" }}>
              ← NOVA AVALIAÇÃO
            </button>
            <button onClick={() => { saveToHistory(); alert('✓ Salvo no histórico!'); }}
              style={{ flex:1, background:`linear-gradient(135deg, ${accent}22, ${accent}08)`, border:`1px solid ${accent}`, color:accent, padding:"0.9rem", borderRadius:10, fontSize:"0.8rem", fontWeight:600, letterSpacing:"0.08em", cursor:"pointer" }}>
              💾 SALVAR
            </button>
          </div>
          
          <div style={{ display:"flex", gap:"0.8rem" }}>
            <button onClick={exportToJSON}
              style={{ flex:1, background:"transparent", border:`1px solid #60a5fa40`, color:"#60a5fa", padding:"0.9rem", borderRadius:10, fontSize:"0.75rem", fontWeight:600, letterSpacing:"0.08em", cursor:"pointer" }}>
              📄 EXPORTAR JSON
            </button>
            <button onClick={exportToCSV}
              style={{ flex:1, background:"transparent", border:`1px solid #4ade8040`, color:"#4ade80", padding:"0.9rem", borderRadius:10, fontSize:"0.75rem", fontWeight:600, letterSpacing:"0.08em", cursor:"pointer" }}>
              📊 EXPORTAR CSV
            </button>
            <button onClick={() => window.print()}
              style={{ flex:1, background:`linear-gradient(135deg, ${GOLD}22, ${GOLD}08)`, border:`1px solid ${GOLD}`, color:GOLD, padding:"0.9rem", borderRadius:10, fontSize:"0.75rem", fontWeight:600, letterSpacing:"0.08em", cursor:"pointer" }}>
              🖨️ IMPRIMIR
            </button>
          </div>
        </div>

        <div style={{ marginTop:"2.5rem", padding:"1.5rem", background:"#060d18", borderRadius:10, border:`1px solid ${BORDER}` }}>
          <div style={{ fontSize:"0.65rem", color:"#4a7090", lineHeight:1.7, textAlign:"center" }}>
            <strong style={{ color:GOLD }}>IMPORTANTE:</strong> Esta avaliação é uma ferramenta auxiliar baseada nos princípios diagnósticos da Medicina Tradicional Chinesa conforme sistematizado pelo Instituto Nilza Ferreira. Os protocolos gerados devem ser validados por um profissional qualificado e adaptados ao contexto clínico individual de cada paciente. A prática da acupuntura requer formação técnica adequada e registro profissional.
          </div>
        </div>
      </div>
    </div>
  );
}
